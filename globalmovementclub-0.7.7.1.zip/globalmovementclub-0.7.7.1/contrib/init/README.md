Sample configuration files for:

SystemD: gmcd.service
Upstart: gmcd.conf
OpenRC:  gmcd.openrc
         gmcd.openrcconf
CentOS:  gmcd.init
OS X:    org.globalmovementclub.gmcd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
